<?php
	$client_settings = [
		"approve_id"=>"eyJpdiI6ImVMMk1TRWZNeE82RFA5aks0engzZGc9PSIsInZhbHVlIjoibWZpQmhldzhZNnFNRmQ2d0tnQzBuQT09IiwibWFjIjoiYWIwYWUzM2YzOGVmYWZmZjg0YTE0YzFjYjIyNDVkNGVhN2NjZjcxYTM2MDZhMzI4ZTA3YjU5YjJiYWZhYzU3MyJ9",
		"approve_url"=>"https://dev.kwipped.com",
		"test"=>true
	];
?>
