<?php
namespace com\kwipped\approve\wordpress\devtools;
//****************************************************************************************
//* You should not modify the code below. It assures the correct format needed by Approve.
//*****************************************************************************************
?>	